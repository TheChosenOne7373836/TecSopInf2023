
Pegasus Mail System, Pegasus Mail for 32-bit Windows, v4.63
Copyright (c) 1993-2011, David Harris, All Rights Reserved.
--------------------------------------------------------------------

Pegasus Mail is free software, provided as a service to the broader
Internet Community. It is not in the public domain and is fully-
supported. For terms of distribution and use, please see the Pegasus
Mail online help system.

For more information on Pegasus Mail and its companion mail server
product, Mercury, please visit our web site, at:

   http://www.pmail.com

or visit the Pegasus Mail and Mercury online community at

   http://community.pmail.com
