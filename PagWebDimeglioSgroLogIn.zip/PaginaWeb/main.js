window.addEventListener("load", function(){
    this.document.getElementById("loader").classList.toggle("loader2")
})